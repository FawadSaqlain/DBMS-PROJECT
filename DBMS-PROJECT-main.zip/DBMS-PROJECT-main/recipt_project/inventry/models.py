from django.db import connection
from django.db import IntegrityError
from django.views.decorators.csrf import csrf_exempt

def search_products(search_column, search_value):
    with connection.cursor() as cursor:
        # Ensure the search column is valid to prevent SQL injection
        valid_columns = ['prod_code', 'product_description', 'prod_quant', 'prod_sale_price', 'quantity_price_sale', 'updated_datetime', 'added_by_employ']
        
        # If search_column is 'all', construct a different query
        if search_column == 'all':
            sql = """
            SELECT * FROM product
            WHERE LOWER(prod_code) LIKE LOWER(%s)
            OR LOWER(product_description) LIKE LOWER(%s)
            OR LOWER(CAST(prod_quant AS VARCHAR(50))) LIKE LOWER(%s)
            OR LOWER(CAST(prod_sale_price AS VARCHAR(50))) LIKE LOWER(%s)
            OR LOWER(CAST(quantity_price_sale AS VARCHAR(50))) LIKE LOWER(%s)
            OR LOWER(CAST(updated_datetime AS VARCHAR(50))) LIKE LOWER(%s)
            OR LOWER(CAST(added_by_employ AS VARCHAR(50))) LIKE LOWER(%s)
            """
            like_value = f'%{search_value}%'
            cursor.execute(sql, [like_value] * 7)  # Repeat the like_value for all 7 placeholders
        else:
            # Validate the search column
            if search_column not in valid_columns:
                raise ValueError("Invalid search column provided.")

            # Prepare the SQL query for a specific column
            if search_column == 'prod_quant':
                # For numeric fields, we need to ensure we convert to int
                try:
                    search_value = int(search_value)  # Convert to int for numeric fields
                except ValueError:
                    raise ValueError("Search value for quantity must be a valid integer.")

            sql = f"SELECT * FROM product WHERE LOWER(CAST({search_column} AS NVARCHAR(50))) LIKE LOWER(%s)"
            
            # Execute the query with the provided search value
            cursor.execute(sql, [f'%{search_value}%'])

        results = cursor.fetchall()
        return results



@csrf_exempt
def add_each_item(prod_code, prod_description, prod_quantity, prod_sale_price, quantity_price_sale, updated_datetime, username):
    product=get_product(prod_code)
    # product=product[0]
    # print(f"condition for updating  if {product[1]} != {prod_description} or {product[4]} != {quantity_price_sale} or {product[6]} != {username}:")
    """Inserts or updates product data in the product table."""
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT COUNT(*) FROM dbo.product WHERE prod_code = %s", [prod_code])
            exists = cursor.fetchone()[0]

            if exists:
                # Update the existing record
                product=get_product(prod_code)
                product=product[0]
                # print(f"condition for updating  if {product[1]} != {prod_description} or {product[4]} != {quantity_price_sale} or {product[6]} != {username}:")
                if product[1] != prod_description or product[4] != quantity_price_sale :
                    cursor.execute("""
                        UPDATE dbo.product
                        SET product_description = %s,
                            prod_quant = %s,
                            prod_sale_price = %s,
                            quantity_price_sale = %s,
                            updated_datetime = %s,
                            added_by_employ = %s
                        WHERE prod_code = %s
                    """, [prod_description, prod_quantity, prod_sale_price, quantity_price_sale, updated_datetime, username, prod_code])
            else:
                # Insert new record
                cursor.execute("""
                    INSERT INTO dbo.product (prod_code, product_description, prod_quant, prod_sale_price, quantity_price_sale, updated_datetime, added_by_employ)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """, [prod_code, prod_description, prod_quantity, prod_sale_price, quantity_price_sale, updated_datetime, username])
    except IntegrityError as e:
        print(f"line 81 Error inserting/updating record: {e}")
    except Exception as e:
        print(f"line 83 An unexpected error occurred: {e}")

@csrf_exempt
def get_product(prod_code):
    """Retrieves product data from the product table."""
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM dbo.product WHERE prod_code = %s", [prod_code])
            products = cursor.fetchall()
            return [list(product) for product in products]
    except Exception as e:
        print(f"line 94 Error fetching product data: {e}")
        return []
from django.db import connection
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def get_product(prod_code):
    """Retrieves product data from the product table and returns the first product found."""
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM dbo.product WHERE prod_code = %s", [prod_code])
            product = cursor.fetchone()  # Fetch the first result directly
            if product:
                return list(product)  # Return the product as a list
            else:
                return None  # Return None if no product is found
    except Exception as e:
        print(f"line  111 Error fetching product data: {e}")
        return None

# Usage
# product = get_product(prod_code)
# if product:
#     # `product` is now the first item found with the given `prod_code`
#     print(product)
# else:
#     print("Product not found.")

@csrf_exempt
def view_inventory(request):
    """Returns a list of products in the inventory."""
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM dbo.product")
            products = cursor.fetchall()
            return [list(product) for product in products]
    except Exception as e:
        print(f"line 131 Error fetching product data: {e}")
        return []
def view_sorted_inventory(request, asc_decs, sort_by):
    """Returns a list of sorted products in the inventory."""
    try:
        with connection.cursor() as cursor:
            order = "ASC" if asc_decs == 0 else "DESC"
            query = f"SELECT * FROM Product ORDER BY {sort_by} {order}"
            cursor.execute(query)
            products = cursor.fetchall()
            return [list(product) for product in products]
    except Exception as e:
        print(f"line 143 Error fetching product data: {e}")
        return []

def delete_item(prod_code):
    """Deletes a product from the product table."""
    try:
        with connection.cursor() as cursor:
            cursor.execute("DELETE FROM dbo.product WHERE prod_code = %s", [prod_code])
        connection.commit()
    except Exception as e:
        print(f"line 153 Error while deleting product: {e}")
        connection.rollback()
