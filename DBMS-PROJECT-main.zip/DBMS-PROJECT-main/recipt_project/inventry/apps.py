from django.apps import AppConfig


class InventryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'inventry'
